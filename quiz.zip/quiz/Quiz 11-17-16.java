// Jonathan De Rouen
public class LinkedListSet {

    class Node {
        Node next;
        String value;

        public Node(Node next, String value) {
            this.next = next;
            this.value = value;
        }
    }

   
    Node first;
    int n;

    public LinkedListSet() {
        first = null;
        n = 0;
    }

    public boolean isDuplicate (String word){
         Node current = first;
         boolean compare = false;
         boolean x = true;
         while((current != null) && (compare == false) ){
             if(!current.item.equals(word)){
                 current = current.next;
             } else {
                 compare = true;
             }
         }
         if (current != null){
            current.count++;
         } else {
            x = false;
        }
        return x;
    }
     
     
     public void add (String word){
         if(!(isDuplicate(word))){
             Node next = new Node(first,word);
             first = next;
             n++;
         } else {
             n++;
         }
     }
//  run time for add is equal to n for adding string word.  
     

    public String removeFirst() {
        String temp = first.value;
        first = first.next;
        n--;
        return temp;
    }


    public void removeOne(String s) {
        Node current = first;
        Node prev = null;
        if (first.value.equals(s)) {
            first = first.next;
            n--;
            return;
        }
        while (current != null) {
            if (current.value.equals(s)) {
                prev.next = current.next;
                n--;
                return;
            }
            prev = current;
            current = current.next;
        }
    }
// run time is equal to n for removing string s
    
    public void removeAll(String s) {
        throw new UnsupportedOperationException();
    }

}